const btnHamburguesa = document.getElementById('btn-hamburguesa')
const menu = document.getElementById('menu')

btnHamburguesa.addEventListener('click', () => {
    menu.classList.toggle('active')
})

  document.getElementById('select-all').addEventListener('change', function(e){
           const checked = e.target.checked;
          document.querySelectorAll('input[name="ingrediente"]').forEach(i => i.checked = checked);
      });
       // Mostrar selección
       document.getElementById('ver-seleccion').addEventListener('click', () => {
            const seleccion = Array.from(document.querySelectorAll('input[name="ingrediente"]:checked')).map(i => i.value);
            document.getElementById('resultado').textContent = seleccion.length ? 'Seleccionado: ' + seleccion.join(', ') : 'Nada seleccionado';
        });

const pedir = document.getElementById('btn-pedir');
if (pedir) {
    pedir.addEventListener('click', () => {
        const seleccion = Array.from(document.querySelectorAll('input[name="ingrediente"]:checked')).map(i => i.value);
        if (seleccion.length) {
            alert('Has pedido: ' + seleccion.join(', '));
        } else {
            alert('No has seleccionado ningún producto');
        }
    });
}